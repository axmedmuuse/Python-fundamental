# A lambda function to calculate the square of a number
square = lambda x: x ** 2

# Test the lambda function
print(square(5))  # Output: 25