def sum_and_product(a, b):
    return a + b, a * b

# Test the function
sum_result, product_result = sum_and_product(3, 4)
print(f"Sum: {sum_result}, Product: {product_result}")
# Output: Sum: 7, Product: 12