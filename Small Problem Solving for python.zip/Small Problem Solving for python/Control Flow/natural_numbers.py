def print_natural_numbers(n):
    for i in range(1, n + 1):
        print(i)

# Test the function
print_natural_numbers(5)
# Output:
# 1
# 2
# 3
# 4
# 5